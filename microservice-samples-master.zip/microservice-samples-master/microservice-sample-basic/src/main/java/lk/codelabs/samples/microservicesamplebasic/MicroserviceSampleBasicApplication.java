package lk.codelabs.samples.microservicesamplebasic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceSampleBasicApplication {

    public static void main(String[] args) {
        SpringApplication.run(MicroserviceSampleBasicApplication.class, args);
    }

}
